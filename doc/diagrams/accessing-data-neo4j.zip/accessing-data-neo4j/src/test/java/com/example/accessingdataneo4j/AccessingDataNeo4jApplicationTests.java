package com.example.accessingdataneo4j;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccessingDataNeo4jApplicationTests {

	@Test
	void contextLoads() {
	}

}
